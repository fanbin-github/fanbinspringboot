package com.fb.springbootfbtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootfbtestApplicationTests {

	@Test
	void contextLoads() {
	}

}
